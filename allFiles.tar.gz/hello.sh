#! /bin/bash

age=24
name="Angelo Zambrano"
echo $UBI_REPOS
echo "Hello, $name!"

export name

./hello_2
