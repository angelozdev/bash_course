# !/bin/bash

echo "Numbre:           " $0
echo "Argumento 1:      " $1
echo "Argumento 2:      " $?
echo "Contador de args: " $#
echo "Todos los args:   " $*
