#!/bin/bash

arr=(3 5 2 43)

echo "My array $#arr"
